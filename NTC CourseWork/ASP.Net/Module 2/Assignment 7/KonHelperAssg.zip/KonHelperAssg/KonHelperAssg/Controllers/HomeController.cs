﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KonHelperAssg.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Let's gather data now";
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Students(string lastName, string firstName, string gender, string langauges, bool enjoyASP, string color, string degree)
        {
            ViewBag.Message = "Student's Page.";
            ViewBag.resultsfname = Request.Form["firstName"];
            ViewBag.resultslname = Request.Form["lastName"];
            ViewBag.resultsgender = Request.Form["gender"];
            ViewBag.resultslang = Request.Form["languages"];
            ViewBag.resultsASP = Convert.ToBoolean(enjoyASP);

            if(ViewBag.resultsASP == true)
            {
                ViewBag.displayasp = "YES";
            }
            else
            {
                ViewBag.displayasp = "NO";
            }

            ViewBag.resultscolor = Request.Form["color"];
            ViewBag.resultsdegree = Request.Form["degreeType"];
            
            return View();
        }
    }
}